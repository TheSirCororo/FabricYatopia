SpigotMC Build Data
===================

Data needed to build custom MC servers.

(c) 2014-2020 SpigotMC Pty. Ltd.
